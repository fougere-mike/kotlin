sub unsignedTests_rTestRunner_k_(m as Object)
    m.suite_Str_Function1TestRunnerV_k_("Unsigned Basics", {invoke: function(m as Object) as Void
        m.test_Str_Function0V_k_("UInt basics", {invoke: function() as Void
            a = UInt_create_I_UInt_k_(1)
            b = UInt_create_I_UInt_k_(2)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(3), a + b)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(0), UInt_Companion_get_MIN_VALUE_UInt_k_())
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(-1), UInt_Companion_get_MAX_VALUE_UInt_k_())
        end function})
        m.test_Str_Function0V_k_("UInt comparison", {invoke: function() as Void
            a = UInt_create_I_UInt_k_(1)
            b = UInt_create_I_UInt_k_(2)
            assertTrue_Z_StrN_k_((a < b) < 0)
            assertTrue_Z_StrN_k_((b > a) > 0)
            assertEquals_AnyN_AnyN_StrN_k_(0, a.compareTo_UInt_I_k_(a))
        end function})
        m.test_Str_Function0V_k_("UInt arithmetic", {invoke: function() as Void
            a = UInt_create_I_UInt_k_(10)
            b = UInt_create_I_UInt_k_(3)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(13), a + b)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(7), a - b)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(30), a * b)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(3), a / b)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(1), a mod b)
        end function})
        m.test_Str_Function0V_k_("UInt conversions", {invoke: function() as Void
            i = -1
            u = toUInt_rI_UInt_k_(i)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_Companion_get_MAX_VALUE_UInt_k_(), u)
            assertEquals_AnyN_AnyN_StrN_k_(-1, u.toULong_ULong_k_().get_data())
        end function})
        m.test_Str_Function0V_k_("ULong basics", {invoke: function() as Void
            a = ULong_create_J_ULong_k_(1&)
            b = ULong_create_J_ULong_k_(2&)
            assertEquals_AnyN_AnyN_StrN_k_(ULong_create_J_ULong_k_(3&), a + b)
            assertEquals_AnyN_AnyN_StrN_k_(ULong_create_J_ULong_k_(0&), ULong_Companion_get_MIN_VALUE_ULong_k_())
            assertEquals_AnyN_AnyN_StrN_k_(ULong_create_J_ULong_k_(-1&), ULong_Companion_get_MAX_VALUE_ULong_k_())
        end function})
        m.test_Str_Function0V_k_("UByte basics", {invoke: function() as Void
            a = UByte_create_B_UByte_k_(1)
            b = UByte_create_B_UByte_k_(2)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(3), a + b)
            assertEquals_AnyN_AnyN_StrN_k_(UByte_create_B_UByte_k_(0), UByte_Companion_get_MIN_VALUE_UByte_k_())
            assertEquals_AnyN_AnyN_StrN_k_(UByte_create_B_UByte_k_(-1), UByte_Companion_get_MAX_VALUE_UByte_k_())
        end function})
        m.test_Str_Function0V_k_("UShort basics", {invoke: function() as Void
            a = UShort_create_S_UShort_k_(1)
            b = UShort_create_S_UShort_k_(2)
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(3), a + b)
            assertEquals_AnyN_AnyN_StrN_k_(UShort_create_S_UShort_k_(0), UShort_Companion_get_MIN_VALUE_UShort_k_())
            assertEquals_AnyN_AnyN_StrN_k_(UShort_create_S_UShort_k_(-1), UShort_Companion_get_MAX_VALUE_UShort_k_())
        end function})
    end function})
    m.suite_Str_Function1TestRunnerV_k_("Unsigned Arrays", {invoke: function(m as Object) as Void
        m.test_Str_Function0V_k_("UIntArray", {invoke: function() as Void
            arr = UIntArray_I_Function1IUInt_UIntArray_k_(3, {invoke: function(it as Integer) as Object
                return UInt_create_I_UInt_k_(it + 1)
            end function})
            assertEquals_AnyN_AnyN_StrN_k_(3, arr.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(1), arr.get_I_UInt_k_(0))
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(2), arr.get_I_UInt_k_(1))
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(3), arr.get_I_UInt_k_(2))
            arr.set_I_UInt_k_(1, UInt_create_I_UInt_k_(10))
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(10), arr.get_I_UInt_k_(1))
        end function})
        m.test_Str_Function0V_k_("UIntArray creation", {invoke: function() as Void
            arr = uintArrayOf_UIntArray_UIntArray_k_([UInt_create_I_UInt_k_(1), UInt_create_I_UInt_k_(2), UInt_create_I_UInt_k_(3)])
            assertEquals_AnyN_AnyN_StrN_k_(3, arr.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(1), arr.get_I_UInt_k_(0))
        end function})
        m.test_Str_Function0V_k_("ULongArray", {invoke: function() as Void
            arr = ULongArray_I_Function1IULong_ULongArray_k_(2, {invoke: function(it as Integer) as Object
                return ULong_create_J_ULong_k_(it)
            end function})
            assertEquals_AnyN_AnyN_StrN_k_(2, arr.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(ULong_create_J_ULong_k_(0&), arr.get_I_ULong_k_(0))
            assertEquals_AnyN_AnyN_StrN_k_(ULong_create_J_ULong_k_(1&), arr.get_I_ULong_k_(1))
        end function})
        m.test_Str_Function0V_k_("UByteArray", {invoke: function() as Void
            arr = UByteArray_I_Function1IUByte_UByteArray_k_(2, {invoke: function(it as Integer) as Object
                return UByte_create_B_UByte_k_(it)
            end function})
            assertEquals_AnyN_AnyN_StrN_k_(2, arr.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(UByte_create_B_UByte_k_(0), arr.get_I_UByte_k_(0))
        end function})
        m.test_Str_Function0V_k_("UShortArray", {invoke: function() as Void
            arr = UShortArray_I_Function1IUShort_UShortArray_k_(2, {invoke: function(it as Integer) as Object
                return UShort_create_S_UShort_k_(it)
            end function})
            assertEquals_AnyN_AnyN_StrN_k_(2, arr.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(UShort_create_S_UShort_k_(0), arr.get_I_UShort_k_(0))
        end function})
    end function})
    m.suite_Str_Function1TestRunnerV_k_("Unsigned Ranges", {invoke: function(m as Object) as Void
        m.test_Str_Function0V_k_("UIntRange", {invoke: function() as Void
            range = UInt_create_I_UInt_k_(1).rangeTo_UInt_UIntRange_k_(UInt_create_I_UInt_k_(5))
            list = toList_rIterableAnyN_ListAnyN_k_(range)
            assertEquals_AnyN_AnyN_StrN_k_(5, list.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(1), list.get_I_AnyN_k_(0))
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(5), list.get_I_AnyN_k_(4))
        end function})
        m.test_Str_Function0V_k_("UIntRange until", {invoke: function() as Void
            range = until_rUInt_UInt_UIntRange_k_(UInt_create_I_UInt_k_(1), UInt_create_I_UInt_k_(5))
            list = toList_rIterableAnyN_ListAnyN_k_(range)
            assertEquals_AnyN_AnyN_StrN_k_(4, list.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(1), list.get_I_AnyN_k_(0))
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(4), list.get_I_AnyN_k_(3))
        end function})
        m.test_Str_Function0V_k_("UIntRange downTo", {invoke: function() as Void
            range = downTo_rUInt_UInt_UIntProgression_k_(UInt_create_I_UInt_k_(5), UInt_create_I_UInt_k_(1))
            list = toList_rIterableAnyN_ListAnyN_k_(range)
            assertEquals_AnyN_AnyN_StrN_k_(5, list.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(5), list.get_I_AnyN_k_(0))
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(1), list.get_I_AnyN_k_(4))
        end function})
        m.test_Str_Function0V_k_("UIntRange step", {invoke: function() as Void
            range = step_rUIntProgression_I_UIntProgression_k_(UInt_create_I_UInt_k_(1).rangeTo_UInt_UIntRange_k_(UInt_create_I_UInt_k_(10)), 2)
            list = toList_rIterableAnyN_ListAnyN_k_(range)
            assertEquals_AnyN_AnyN_StrN_k_(5, list.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(1), list.get_I_AnyN_k_(0))
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(3), list.get_I_AnyN_k_(1))
            assertEquals_AnyN_AnyN_StrN_k_(UInt_create_I_UInt_k_(9), list.get_I_AnyN_k_(4))
        end function})
        m.test_Str_Function0V_k_("ULongRange", {invoke: function() as Void
            range = ULong_create_J_ULong_k_(1&).rangeTo_ULong_ULongRange_k_(ULong_create_J_ULong_k_(3&))
            list = toList_rIterableAnyN_ListAnyN_k_(range)
            assertEquals_AnyN_AnyN_StrN_k_(3, list.get_size())
            assertEquals_AnyN_AnyN_StrN_k_(ULong_create_J_ULong_k_(1&), list.get_I_AnyN_k_(0))
            assertEquals_AnyN_AnyN_StrN_k_(ULong_create_J_ULong_k_(3&), list.get_I_AnyN_k_(2))
        end function})
    end function})
end sub
