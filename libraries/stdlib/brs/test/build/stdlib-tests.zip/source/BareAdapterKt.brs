function BareAdapter_create_k_() as Object
    this = {}
    this.__type = "BareAdapter"
    this.__proto = ["BareAdapter", "FrameworkAdapter"]
    this.__id = __kotlin_nextObjectId()
    this.equals = Any_equals_AnyN_k_
    this.hashCode = Any_hashCode_k_
    this.toString = Any_toString_k_
    this.suite_Str_Z_Function0V_k_ = BareAdapter_suite_Str_Z_Function0V_k_
    this.test_Str_Z_Function0V_k_ = BareAdapter_test_Str_Z_Function0V_k_
    this.printSummary_k_ = BareAdapter_printSummary_k_
    this.__get_results = BareAdapter___get_results_k_
    this.__get_currentSuite = BareAdapter___get_currentSuite_k_
    this.__set_currentSuite = BareAdapter___set_currentSuite_Str_k_
    this.results = mutableListOf_k_()
    this.currentSuite = ""
    return this
end function

sub BareAdapter_suite_Str_Z_Function0V_k_(name as String, ignored as Boolean, suiteFn as Object)
    if ignored then
        println_AnyN_k_("[SUITE IGNORED] " + name)
        return
    end if
    m.__set_currentSuite(name)
    println_AnyN_k_("[SUITE START] " + name)
    suiteFn.invoke_k_()
    println_AnyN_k_("[SUITE PASS] " + name)
end sub

sub BareAdapter_test_Str_Z_Function0V_k_(name as String, ignored as Boolean, testFn as Object)
    __when_tmp0 = invalid
    if isNotEmpty_rStr_k_(m.__get_currentSuite()) then
        __when_tmp0 = ((m.__get_currentSuite() + ".") + name)
    else if true then
        __when_tmp0 = name
    end if
    fullName = __when_tmp0

    if ignored then
        println_AnyN_k_("[TEST IGNORED] " + fullName)
        m.__get_results().add_AnyN_k_(BareAdapter_TestResult_create_Str_Str_Str_StrN_k_(m.__get_currentSuite(), name, "IGNORED", invalid))
        return
    end if
    println_AnyN_k_("[TEST START] " + fullName)
    testFn.invoke_k_()
    println_AnyN_k_("[TEST PASS] " + fullName)
    m.__get_results().add_AnyN_k_(BareAdapter_TestResult_create_Str_Str_Str_StrN_k_(m.__get_currentSuite(), name, "PASS", invalid))
end sub

sub BareAdapter_printSummary_k_()
    total = m.__get_results().__get_size()
    passed = count_rIterable_Function1Z_k_(m.__get_results(), BareAdapter_printSummary_lambda_create_k_())
    failed = count_rIterable_Function1Z_k_(m.__get_results(), BareAdapter_printSummary_lambda_1_create_k_())
    ignored = count_rIterable_Function1Z_k_(m.__get_results(), BareAdapter_printSummary_lambda_2_create_k_())
    println_AnyN_k_(chr(10) + "[TEST SUMMARY]")
    println_AnyN_k_("Total: " + __kotlin_numToStr_I_k_(total))
    println_AnyN_k_("Passed: " + __kotlin_numToStr_I_k_(passed))
    println_AnyN_k_("Failed: " + __kotlin_numToStr_I_k_(failed))
    println_AnyN_k_("Ignored: " + __kotlin_numToStr_I_k_(ignored))
    println_AnyN_k_("[TEST SUMMARY END]")
end sub

function BareAdapter___get_results_k_() as Object
    return m.results
end function

function BareAdapter___get_currentSuite_k_() as String
    return m.currentSuite
end function

sub BareAdapter___set_currentSuite_Str_k_(value as String)
    m.currentSuite = value
end sub

function BareAdapter_TestResult_create_Str_Str_Str_StrN_k_(suite as String, test as String, status as String, message as Dynamic) as Object
    this = {}
    this.__type = "BareAdapter_TestResult"
    this.__proto = ["BareAdapter_TestResult"]
    this.__id = __kotlin_nextObjectId()
    this.suite = suite
    this.test = test
    this.status = status
    this.message = message
    this.equals = BareAdapter_TestResult_equals
    this.hashCode = BareAdapter_TestResult_hashCode
    this.toString = BareAdapter_TestResult_toString
    this.copy = BareAdapter_TestResult_copy
    this.component1 = BareAdapter_TestResult_component1
    this.component2 = BareAdapter_TestResult_component2
    this.component3 = BareAdapter_TestResult_component3
    this.component4 = BareAdapter_TestResult_component4
    return this
end function

function BareAdapter_TestResult_equals(other as Object) as Boolean
    if Type(other) <> "roAssociativeArray" then
        return false
    end if
    if other.__type <> "BareAdapter_TestResult" then
        return false
    end if
    if m.suite <> other.suite then
        return false
    end if
    if m.test <> other.test then
        return false
    end if
    if m.status <> other.status then
        return false
    end if
    if m.message <> other.message then
        return false
    end if
    return true
end function

function BareAdapter_TestResult_hashCode() as Integer
    result = 1
    result = ((result * 31) + m.suite)
    result = ((result * 31) + m.test)
    result = ((result * 31) + m.status)
    result = ((result * 31) + m.message)
    return result
end function

function BareAdapter_TestResult_toString() as String
    return ((((((("BareAdapter_TestResult(suite=" + m.suite) + ", test=") + m.test) + ", status=") + m.status) + ", message=") + m.message) + ")"
end function

function BareAdapter_TestResult_copy(suite = invalid, test = invalid, status = invalid, message = invalid) as Object
    if suite = invalid then
        suite = m.suite
    end if
    if test = invalid then
        test = m.test
    end if
    if status = invalid then
        status = m.status
    end if
    if message = invalid then
        message = m.message
    end if
    return BareAdapter_TestResult_create_Str_Str_Str_StrN_k_(suite, test, status, message)
end function

function BareAdapter_TestResult_component1() as String
    return m.suite
end function

function BareAdapter_TestResult_component2() as String
    return m.test
end function

function BareAdapter_TestResult_component3() as String
    return m.status
end function

function BareAdapter_TestResult_component4() as Dynamic
    return m.message
end function

function BareAdapter_printSummary_lambda_create_k_() as Object
    this = {}
    this.__type = "BareAdapter_printSummary_lambda"
    this.__proto = ["BareAdapter_printSummary_lambda", "Function1", "Function"]
    this.__id = __kotlin_nextObjectId()
    this.equals = Any_equals_AnyN_k_
    this.hashCode = Any_hashCode_k_
    this.toString = Any_toString_k_
    this.invoke_AnyN_k_ = BareAdapter_printSummary_lambda_invoke_AnyN_k_
    return this
end function

function BareAdapter_printSummary_lambda_invoke_AnyN_k_(it as Object) as Boolean
    return it.status = "PASS"
end function

function BareAdapter_printSummary_lambda_1_create_k_() as Object
    this = {}
    this.__type = "BareAdapter_printSummary_lambda_1"
    this.__proto = ["BareAdapter_printSummary_lambda_1", "Function1", "Function"]
    this.__id = __kotlin_nextObjectId()
    this.equals = Any_equals_AnyN_k_
    this.hashCode = Any_hashCode_k_
    this.toString = Any_toString_k_
    this.invoke_AnyN_k_ = BareAdapter_printSummary_lambda_1_invoke_AnyN_k_
    return this
end function

function BareAdapter_printSummary_lambda_1_invoke_AnyN_k_(it as Object) as Boolean
    return it.status = "FAIL"
end function

function BareAdapter_printSummary_lambda_2_create_k_() as Object
    this = {}
    this.__type = "BareAdapter_printSummary_lambda_2"
    this.__proto = ["BareAdapter_printSummary_lambda_2", "Function1", "Function"]
    this.__id = __kotlin_nextObjectId()
    this.equals = Any_equals_AnyN_k_
    this.hashCode = Any_hashCode_k_
    this.toString = Any_toString_k_
    this.invoke_AnyN_k_ = BareAdapter_printSummary_lambda_2_invoke_AnyN_k_
    return this
end function

function BareAdapter_printSummary_lambda_2_invoke_AnyN_k_(it as Object) as Boolean
    return it.status = "IGNORED"
end function
